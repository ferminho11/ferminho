Import-Module ActiveDirectory

$Username = "jdoe"
Unlock-ADAccount -Identity $Username

Write-Host "Account unlocked."