Connect-MgGraph -Scopes "User.Read.All"

Get-MgUser | Select DisplayName,UserPrincipalName |
Export-Csv "EntraIDUsers.csv" -NoTypeInformation