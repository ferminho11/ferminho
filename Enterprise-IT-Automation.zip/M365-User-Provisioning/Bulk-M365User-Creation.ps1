Connect-MgGraph -Scopes "User.ReadWrite.All"

$Users = Import-Csv "users.csv"

foreach ($User in $Users) {
    $PasswordProfile = @{
        Password = $User.Password
        ForceChangePasswordNextSignIn = $true
    }

    New-MgUser -DisplayName $User.DisplayName `
    -UserPrincipalName $User.UserPrincipalName `
    -MailNickname $User.MailNickname `
    -AccountEnabled:$true -PasswordProfile $PasswordProfile

    Write-Host "$($User.DisplayName) created."
}