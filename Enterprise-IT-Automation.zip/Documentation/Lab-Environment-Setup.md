# Lab Environment Setup

- Microsoft 365 Developer Tenant
- Azure Free Subscription
- Windows Server Lab VM
- Ubuntu VM
- VMware / VirtualBox