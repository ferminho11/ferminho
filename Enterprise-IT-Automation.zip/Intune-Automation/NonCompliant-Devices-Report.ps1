Connect-MgGraph -Scopes "DeviceManagementManagedDevices.Read.All"

Get-MgDeviceManagementManagedDevice |
Where {$_.ComplianceState -ne "compliant"} |
Select DeviceName,ComplianceState |
Export-Csv "NonCompliantDevices.csv" -NoTypeInformation