Connect-MgGraph -Scopes "User.ReadWrite.All","Group.ReadWrite.All","Directory.ReadWrite.All"

$DisplayName = "John Doe"
$UserPrincipalName = "john.doe@yourtenant.onmicrosoft.com"
$MailNickname = "johndoe"
$Password = "TempP@ssw0rd123"
$LicenseSku = "ENTERPRISEPACK"
$SecurityGroupName = "Basic-User-Access"

$PasswordProfile = @{
    Password = $Password
    ForceChangePasswordNextSignIn = $true
}

New-MgUser -DisplayName $DisplayName -UserPrincipalName $UserPrincipalName `
-MailNickname $MailNickname -AccountEnabled:$true -PasswordProfile $PasswordProfile

$Sku = Get-MgSubscribedSku | Where-Object {$_.SkuPartNumber -eq $LicenseSku}

Set-MgUserLicense -UserId $UserPrincipalName `
-AddLicenses @{SkuId = $Sku.SkuId} -RemoveLicenses @()

$Group = Get-MgGroup -Filter "displayName eq '$SecurityGroupName'"
$User = Get-MgUser -UserId $UserPrincipalName

New-MgGroupMember -GroupId $Group.Id -DirectoryObjectId $User.Id

Write-Host "Provisioning completed successfully."