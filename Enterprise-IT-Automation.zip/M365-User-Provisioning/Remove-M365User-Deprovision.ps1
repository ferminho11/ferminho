Connect-MgGraph -Scopes "User.ReadWrite.All"

$UserPrincipalName = "user@yourtenant.onmicrosoft.com"

Update-MgUser -UserId $UserPrincipalName -AccountEnabled:$false

Set-MgUserLicense -UserId $UserPrincipalName `
-RemoveLicenses @((Get-MgUserLicenseDetail -UserId $UserPrincipalName).SkuId) `
-AddLicenses @()

Write-Host "User deprovisioned."